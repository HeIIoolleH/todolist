import React, {useState} from "react";
import axios from "axios";

const Main = () =>{
    const {sections, setSections} = useState([]);
    
    const getSections = async () => {
        try{
            const result = await axios.get('http://192.168.0.14:8009/')
            return result.data;
        }catch(e){
            alert('getSections : ', e.message)
        }
    };

    const 

}

export default Main;